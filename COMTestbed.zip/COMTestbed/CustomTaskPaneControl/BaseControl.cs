﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace CustomTaskPaneControl
{
    [ComVisible(true)]
    [ProgId("CustomTaskPaneControl.BaseControl")]
    [Guid("DD38ADAB-F63A-4F4A-AC1A-343B385DA2AF")]
    public partial class BaseControl : UserControl
    {
        public BaseControl()
        {
            InitializeComponent();
        }

        [ComVisible(true)]
        public ControlCollection ChildControls
        {
            get
            {
                return this.Controls;
            }
        }
    }
}
