﻿/// With the DEFINES below, comment out all but the one app
/// you will be defining as your add-in. And you can only 
/// define one all others must be deleted or commented out
#define EXCEL
//#define WORD
//#define OUTLOOK
//#define POWERPOINT
#region USINGS
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Office = Microsoft.Office.Core;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;
using PowerPoint = Microsoft.Office.Interop.PowerPoint;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.Reflection;
using System.Windows.Forms;
using CustomTaskPaneControl;
#endregion

namespace COMTestbed
{
    /// <summary>
    /// Specify the GUID of your addin here. You can go to Tools | Create Guid to
    /// get a new GUID.
    /// 
    /// Next, use the same namespace as defined above. This will be the ProgId
    /// used in the registry to define your add-in.
    /// </summary>
    [GuidAttribute("{GUID}"),
    ProgId("{NAMESPACE}.Connect"),
    ClassInterface(ClassInterfaceType.AutoDual)]
    #region IDTExtensibility2
    public class Connect : Object, Extensibility.IDTExtensibility2, Office.IRibbonExtensibility, Office.ICustomTaskPaneConsumer 
    {
#if EXCEL
        private static string APP = "Excel";
#endif
#if WORD
        private static string APP = "Word";
#endif
#if POWERPOINT
        private static string APP = "PowerPoint";
#endif
#if OUTLOOK
        private static string APP = "Outlook";
#endif
        object ThisAddInInstance = null;

        /// <summary>
        /// When we finally do connect and load in Excel we want to get the
        /// reference to the application, so that we can use the application
        /// instace in our UDF as needed
        /// </summary>
        /// <param name="application"></param>
        /// <param name="connectMode"></param>
        /// <param name="addInInst"></param>
        /// <param name="custom"></param>
        public void OnConnection(object application, Extensibility.ext_ConnectMode connectMode, object addInInst, ref System.Array custom)
        {
            // get a reference to the instance of the add-in
#if EXCEL
            Globals.thisAddin.Application = application as Excel.Application;
#endif
#if WORD
            Globals.thisAddin.Application = application as Word.Application;
#endif
#if POWERPOINT
            Globals.thisAddin.Application = application as PowerPoint.Application;
#endif
#if OUTLOOK
            Globals.thisAddin.Appliction = applictation as Outlook.Application;
#endif
            ThisAddInInstance = addInInst;
            Globals.thisAddin.StartAddin();
        }

        /// <summary>
        /// When we disconnect - remove everything - clean up
        /// </summary>
        /// <param name="disconnectMode"></param>
        /// <param name="custom"></param>
        public void OnDisconnection(Extensibility.ext_DisconnectMode disconnectMode, ref System.Array custom)
        {
            Globals.thisAddin.StopAddin();
            // clean up
            Marshal.ReleaseComObject(Globals.thisAddin.Application);
            Globals.thisAddin.Application = null;
            ThisAddInInstance = null;
            GC.Collect();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        /// <summary>
        /// Get the Ribbon UI
        /// </summary>
        /// <param name="RibbonId"></param>
        /// <returns></returns>
        string Office.IRibbonExtensibility.GetCustomUI(string RibbonId)
        {
            return Globals.thisAddin.RequestRibbonXml(RibbonId);
        }

        /// <summary>
        /// Custom taskpane callback
        /// </summary>
        /// <param name="CTPFactoryInst"></param>
        void Office.ICustomTaskPaneConsumer.CTPFactoryAvailable(Office.ICTPFactory CTPFactoryInst)
        {
            Globals.thisAddin.CustomTaskPanes = new CustomTaskPaneCollection(CTPFactoryInst);
        }

        // the following functions are required to be defined, but not needed
        public void OnAddInsUpdate(ref System.Array custom) { }
        public void OnStartupComplete(ref System.Array custom) { }
        public void OnBeginShutdown(ref System.Array custom) { }

        /// <summary>
        /// Registers the COM Automation Add-in in the CURRENT USER context
        /// and then registers it Office on the users system
        /// </summary>
        /// <param name="type"></param>
        [ComRegisterFunctionAttribute]
        public static void RegisterFunction(Type type)
        {
            Assembly thisAssembly = Assembly.GetExecutingAssembly();
            object[] attributes = thisAssembly.GetCustomAttributes(typeof(AssemblyTitleAttribute), false);

            string PATH = thisAssembly.GetName().CodeBase.Replace("\\", "/");
            string ASSM = thisAssembly.FullName;
            string NAME = type.Namespace + "." + type.Name;
            int startPos = ASSM.ToLower().IndexOf("version=") + "version=".Length;
            int len = ASSM.ToLower().IndexOf(",", startPos) - startPos;
            string VER = ASSM.Substring(startPos, len);
            string GUID = "{" + type.GUID.ToString().ToUpper() + "}";
            NAME = type.Namespace + "." + type.Name; // global
            string BASE = @"Classes\" + NAME;
            string CLSID = @"Classes\CLSID\" + GUID;
            
            // open the key
            RegistryKey CU = Registry.CurrentUser.OpenSubKey("Software", true);

            // is this version registred?
            RegistryKey key = CU.OpenSubKey(CLSID + @"\InprocServer32\" + VER);
            if (key == null)
            {
                // The version of this class currently being registered DOES NOT
                // exist in the registry - so we will now register it

                // BASE KEY
                // HKEY_CURRENT_USER\CLASSES\{NAME}
                key = CU.CreateSubKey(BASE);
                key.SetValue("", NAME);

                // HKEY_CURRENT_USER\CLASSES\{NAME}\CLSID}
                key = CU.CreateSubKey(BASE + @"\CLSID");
                key.SetValue("", GUID);

                // CLSID
                // HKEY_CURRENT_USER\CLASSES\CLSID\{GUID}
                key = CU.CreateSubKey(CLSID);
                key.SetValue("", NAME);

                // HKEY_CURRENT_USER\CLASSES\CLSID\{GUID}\Implemented Categories
                key = CU.CreateSubKey(CLSID + @"\Implemented Categories").CreateSubKey("{62C8FE65-4EBB-45e7-B440-6E39B2CDBF29}");

                // HKEY_CURRENT_USER\CLASSES\CLSID\{GUID}\InProcServer32
                key = CU.CreateSubKey(CLSID + @"\InprocServer32");
                key.SetValue("", @"c:\Windows\SysWow64\mscoree.dll");
                key.SetValue("ThreadingModel", "Both");
                key.SetValue("Class", NAME);
                key.SetValue("CodeBase", PATH);
                key.SetValue("Assembly", ASSM);
                key.SetValue("RuntimeVersion", "v4.0.30319");

                // HKEY_CURRENT_USER\CLASSES\CLSID\{GUID}\InProcServer32\{VERSION}
                key = CU.CreateSubKey(CLSID + @"\InprocServer32\" + VER);
                key.SetValue("Class", NAME);
                key.SetValue("CodeBase", PATH);
                key.SetValue("Assembly", ASSM);
                key.SetValue("RuntimeVersion", "v4.0.30319");

                // HKEY_CURRENT_USER\CLASSES\CLSID\{GUID}\ProgId
                key = CU.CreateSubKey(CLSID + @"\ProgId");
                key.SetValue("", NAME);

                // HKEY_CURRENT_USER\CLASSES\CLSID\{GUID}\Progammable
                key = CU.CreateSubKey(CLSID + @"\Programmable");

                // Now register in Office Subkey
                key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Office\Excel", true);
                key = CU.CreateSubKey(@"Software\Microsoft\Office\" + APP + @"\Addins\" + NAME);
                key.SetValue("Description", ((AssemblyTitleAttribute) attributes[0]).Title);
                key.SetValue("FriendlyName", ((AssemblyDescriptionAttribute) attributes[0]).Description);
                key.SetValue("LoadBehavior", 3, RegistryValueKind.DWord);
            }
        }

        /// <summary>
        /// Unregisters the add-in, by removing all the keys
        /// </summary>
        /// <param name="type"></param>
        [ComUnregisterFunctionAttribute]
        public static void UnregisterFunction(Type type)
        {
            string GUID = "{" + type.GUID.ToString().ToUpper() + "}";
            string NAME = type.Namespace + "." + type.Name;
            string BASE = @"Classes\" + NAME;
            string CLSID = @"Classes\CLSID\" + GUID;
            // open the key
            RegistryKey CU = Registry.CurrentUser.OpenSubKey("Software", true);
            // DELETE BASE KEY
            // HKEY_CURRENT_USER\CLASSES\{NAME}
            try
            {
                CU.DeleteSubKeyTree(BASE);
            }
            catch { }
            // HKEY_CURRENT_USER\CLASSES\{NAME}\CLSID}
            try
            {
                CU.DeleteSubKeyTree(CLSID);
            }
            catch { }
            // KKEY_CURRENT_USER\SOFTWARE\Microsoft\Office\{APP}\Addins\{NAME}
            try
            {
                CU.DeleteSubKey(@"\Software\Microsoft\Office\" + APP + @"\Addins\" + NAME);
            }
            catch { }
            MessageBox.Show("Unregistered " + NAME + "!");
        }
    }

    /// <summary>
    /// This class mirrors the Office.CustomTaskPaneCollection
    /// </summary>
    public class CustomTaskPaneCollection
    {
        // Public list of TaskPane items
        public List<CustomTaskPane> Items = new List<CustomTaskPane>();
        private Office.ICTPFactory _paneFactory;

        /// <summary>
        /// CTOR - takes the factor from the interface method
        /// </summary>
        /// <param name="CTPFactoryInst"></param>
        public CustomTaskPaneCollection(Office.ICTPFactory CTPFactoryInst)
        {
            _paneFactory = CTPFactoryInst;
        }

        /// <summary>
        /// Adds a new TaskPane to the collection and takes a 
        /// User Form Control reference for the contents of the
        /// Control Pane
        /// </summary>
        /// <param name="control"></param>
        /// <param name="Title"></param>
        /// <returns></returns>
        public CustomTaskPane Add(Control control, string Title)
        {
            // create a new Pane object
            CustomTaskPane newPane = new CustomTaskPane(control, Title, _paneFactory);
            Items.Add(newPane); // add it to the collection
            return newPane; // return a reference
        }

        /// <summary>
        /// Remove the specific pane from the list
        /// </summary>
        /// <param name="pane"></param>
        public void Remove(CustomTaskPane pane)
        {
            Items.Remove(pane);
            pane.Dispose(); // dispose the pane
        }

        /// <summary>
        /// Get a list
        /// </summary>
        public int Count
        {
            get
            {
                return Items.Count;
            }
        }
    }

    /// <summary>
    /// This class mirrors the Office.CustomTaskPane class 
    /// </summary>
    public class CustomTaskPane
    {
        private string _title = string.Empty;
        private Control _control = null;
        private Office.CustomTaskPane _taskPane;
        private BaseControl _base;
        public string Title { get { return _title; } }
        public event EventHandler VisibleChanged;

        /// <summary>
        /// Get or set the dock position of the TaskPane
        /// </summary>
        public Office.MsoCTPDockPosition DockPosition
        {
            get
            {
                return _taskPane.DockPosition;
            }
            set
            {
                _taskPane.DockPosition = value;
            }
        }

        /// <summary>
        /// Show or hide the CustomTaskPane
        /// </summary>
        public bool Visible
        {
            get
            {
                return _taskPane.Visible;
            }
            set
            {
                _taskPane.Visible = value;
            }
        }

        /// <summary>
        /// Reference to the control
        /// </summary>
        public Control Control { get { return _control; } }

        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="control"></param>
        /// <param name="Title"></param>
        /// <param name="CTPFactoryInst"></param>
        public CustomTaskPane(Control control, string Title, Office.ICTPFactory CTPFactoryInst)
        {
            // create the taskpane control and use the factory to create a new instance of
            // our base control "CustomTaskPaneControl.BaseControl"
            _control = control;
            _title = Title;
            _taskPane = CTPFactoryInst.CreateCTP("CustomTaskPaneControl.BaseControl", Title);
            _taskPane.Width = control.Width + 2;
            _base = (BaseControl)_taskPane.ContentControl;
            _base.ChildControls.Add(control);
            _base.Height = control.Height + 2;
            // when the visibility changes fire an event
            _taskPane.VisibleStateChange += (Office.CustomTaskPane CustomTaskPaneInst) =>
            {
                VisibleChanged(this, new EventArgs());
            };
        }

        /// <summary>
        /// Dispose of the control and collect
        /// </summary>
        public void Dispose()
        {
            try
            {
                _taskPane.Visible = false;
            }
            catch { }
            try
            {
                _control.Dispose();
                _control = null;
                _base.Dispose();
                _base = null;
            }
            catch { }
            GC.Collect();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }

    /// <summary>
    /// Global to provide cross component support
    /// </summary>
    public static class Globals
    {
        private static List<Office.IRibbonUI> _ribbons = new List<Office.IRibbonUI>();
        public static ThisAddin thisAddin = new ThisAddin();
        public static IEnumerable<Office.IRibbonUI> Ribbons
        {
            get
            {
                return _ribbons;
            }
        }
    }

    /// <summary>
    /// This AddIn project is the rot of the add-in
    /// </summary>
    public partial class ThisAddin
    {
        public delegate string RibbonRequestHandler(string RibbonName);
        public event RibbonRequestHandler GetRibbon;
        public event EventHandler Startup;
        public event EventHandler Shutdown;
        public CustomTaskPaneCollection CustomTaskPanes;
#if EXCEL
        public Excel.Application Application;
#endif
#if WORD
        public Word.Application Application;
#endif
#if POWERPOINT
        public PowerPoint.Application Application;
#endif
#if OUTLOOK
        public Outlook.Application Application;
#endif

        public ThisAddin()
        {
            Startup += new EventHandler(ThisAddin_Startup);
            Shutdown += new EventHandler(ThisAddin_Shutdown);
            GetRibbon += new RibbonRequestHandler(ThisAddin_GetRibbon);
        }

        public void StartAddin()
        {
            Startup(this, new EventArgs());
        }

        public void StopAddin()
        {
            Shutdown(this, new EventArgs());
        }

        public string RequestRibbonXml(string name)
        {
            return GetRibbon(name);
        }
    }
    #endregion
    public partial class ThisAddin
    {
        private void ThisAddin_Startup(object sender, System.EventArgs e)
        {

        }

        private void ThisAddin_Shutdown(object sender, System.EventArgs e)
        {
        }

        private string ThisAddin_GetRibbon(string RibbonName)
        {
            return String.Empty;
        }
    }
}
